package demo;

import java.io.File;

/**
 * Created by zhuch on 2017/7/8.
 */
public class tianyao {
    public static void main(String[] args) {
        File file = new File("G:\\����2.dox");
    }
}
