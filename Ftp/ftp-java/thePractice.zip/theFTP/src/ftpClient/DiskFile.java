package ftpClient;

/**
 * Created by zhuch on 2017/7/6.
 */
public class DiskFile {
    public DiskFile() {
    }
}
