package demo;

import javax.swing.*;

/**
 * Created by zhuch on 2017/7/8.
 */
public class hehehe {
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
