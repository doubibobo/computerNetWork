package thisServer;

import javax.swing.*;

/**
 * Created by zhuch on 2017/7/9.
 */
public class theInfor {
    private JTable table1;
    private JButton button1;
    private JButton button2;
}
